# customerservice/views.py
from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .ai_model import GPT2Service
from assistant.ai_model import *

ai_service = GPT2Service()

def read_txt(file_path):
    content = []
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.readlines()
    except Exception as e:
        print(f"Error: The file '{file_path}' could not be read. {e}")
    
    return content

"""def ai_response(file_path, query):
    file_path = '/home/user/customsvc/mysite/propela.txt'
    instruction='use the data provided to answer professionally'
    org_info=read_txt(file_path)
    content=instruction +'data:' + org_info + 'query:' + query
    response = ai_service.generate_response(content)
    return response
    """

def home(request):
    if request.method == 'POST':
        enquiry = request.POST.get('enquiry', '')
        """file_path = '/home/user/customsvc/mysite/propela.txt'
        instruction='use the data provided to answer professionally'
        org_info=read_txt(file_path)
        content=f"{instruction},data:{org_info},query:{enquiry}"""
        response = ai_service.generate_response(enquiry)
        context = {'response': response}
        return render(request, 'assistant.html', context)
    return render(request, 'assistant.html')
