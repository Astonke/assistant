# customerservice/socket_server.py
import socket
from threading import Thread
from .ai_model import generate_response  # Assuming you have an AI model integration

HOST = 'localhost'
PORT = 12345
ORG_DATA_FILE = 'propela.txt'

def read_organizational_data(file_path):
    with open(file_path, 'r') as file:
        data = file.read()
    return data

org_data = read_organizational_data(ORG_DATA_FILE)

def handle_client(client_socket):
    while True:
        # Receive message from client
        client_message = client_socket.recv(1024).decode('utf-8').strip()

        # Example: Retrieve relevant data from org file based on client message
        # For simplicity, just echo back the client message
        response = generate_response(client_message, org_data)

        # Send response back to client
        client_socket.send(response.encode('utf-8'))

    client_socket.close()

def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((HOST, PORT))
    server_socket.listen()
    print(f"Listening on {HOST}:{PORT}...")

    while True:
        client_socket, addr = server_socket.accept()
        print(f"Connection from {addr} has been established.")
        client_thread = Thread(target=handle_client, args=(client_socket,))
        client_thread.start()

    server_socket.close()
