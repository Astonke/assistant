# customerservice/ai_model.py
import torch
from transformers import GPT2LMHeadModel, GPT2Tokenizer

class GPT2Service:
    def __init__(self):
        self.model_name = 'gpt2'
        self.tokenizer = GPT2Tokenizer.from_pretrained(self.model_name)
        self.model = GPT2LMHeadModel.from_pretrained(self.model_name)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model.to(self.device)
        self.model.eval()

    def generate_response(self, input_text):
        input_ids = self.tokenizer.encode(input_text, return_tensors='pt').to(self.device)
        
        # Adjust parameters for generation
        with torch.no_grad():
            outputs = self.model.generate(input_ids,
                                          max_length=200,  # Adjust max_length based on experimentation
                                          num_return_sequences=1,
                                          no_repeat_ngram_size=3,
                                          do_sample=True,  # Enable sampling for more diverse responses
                                          top_k=50,        # Adjust top_k and top_p for better diversity
                                          top_p=0.95,
                                          temperature=0.7,
                                          )
        
        response = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        # Post-process if needed (e.g., filtering or re-ranking)
        
        return response
